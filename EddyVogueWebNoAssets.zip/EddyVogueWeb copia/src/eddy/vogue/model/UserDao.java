package eddy.vogue.model;

import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


public class UserDao {

	private static final String TABLE_NAME = "Utente";
	private static DataSource ds;

	static {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/eddyvogue");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}
	


	public synchronized void doSave(UserBean ub) throws SQLException {
		Connection c = null;
		PreparedStatement p = null;

		String query = "INSERT INTO " + UserDao.TABLE_NAME + " (Nome, Cognome, Email, Pass,Indirizzo,Provincia,Citta,CAP) VALUES (?, ?, ?, ?,?,?,?,?)";

		try {
			c = ds.getConnection();
			p = c.prepareStatement(query);
			p.setString(1, ub.getNome());
			p.setString(2, ub.getCognome());
			p.setString(3, ub.getEmail());
			p.setString(4, toHash(ub.getPassword()));
			p.setString(5, ub.getIndirizzo());
			p.setString(6, ub.getProvincia());
			p.setString(7, ub.getCitta());
			p.setInt(8, ub.getCap());


			p.executeUpdate();
		} finally {
			try {
				if (p != null)
					p.close();
			} finally {
				if (c != null)
					c.close();
			}
		}
	}

	
	public synchronized UserBean doRetrieveByEmailAndPass(String email, String password) throws SQLException {
		Connection c = null;
		PreparedStatement p = null;

		UserBean bean = null;

		String query = "SELECT * FROM " + UserDao.TABLE_NAME + " WHERE Email = ? AND Pass = ?";

		try {
			c = ds.getConnection();
			p = c.prepareStatement(query);
			p.setString(1, email);
			p.setString(2, toHash(password));

			ResultSet rs = p.executeQuery();

			if (rs.next()) {
				bean = new UserBean();
				bean.setId(rs.getInt("ID"));
				bean.setNome(rs.getString("Nome"));
				bean.setCognome(rs.getString("Cognome"));
				bean.setEmail(rs.getString("Email"));
				bean.setProvincia(rs.getString("Provincia"));
				bean.setIndirizzo(rs.getString("Indirizzo"));
				bean.setCitta(rs.getString("Citta"));
				bean.setCap(rs.getInt("CAP"));

			}
		} finally {
			try {
				if (p != null)
					p.close();
			} finally {
				if (c != null)
					c.close();
			}
		}

		return bean;
	}

	
	public boolean checkUserEmailExistance(String email) throws SQLException {
		Connection c = null;
		PreparedStatement p = null;

		boolean exists = false;

		String query = "SELECT * FROM " + UserDao.TABLE_NAME + " WHERE Email = ?";

		try {
			c = ds.getConnection();
			p = c.prepareStatement(query);
			p.setString(1, email);

			ResultSet rs = p.executeQuery();

			if (rs.next())
				exists = true;

		} finally {
			try {
				if (p != null)
					p.close();
			} finally {
				if (c != null)
					c.close();
			}
		}

		return exists;
	}

	private String toHash(String password) {
		String hashString = null;
		try {
			java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-512");
			byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
			hashString = "";
			for (int i = 0; i < hash.length; i++) {
				hashString += Integer.toHexString((hash[i] & 0xFF) | 0x100).toLowerCase().substring(1, 3);
			}
		} catch (java.security.NoSuchAlgorithmException e) {
			System.out.println(e);
		}
		return hashString;
	}

	
}
