package eddy.vogue.control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import eddy.vogue.model.UserBean;
import eddy.vogue.model.UserDao;


@WebServlet("/controllers/user")
public class User extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");

		switch (action) {
			case "logout": {
				request.getSession().invalidate();
				response.sendRedirect(request.getContextPath() + "/");
				break;
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		if (action == null) {
			response.getWriter().write("?action= misses");
			return;
		}
		String nome = request.getParameter("nome");
		String cognome = request.getParameter("cognome");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String citta = request.getParameter("citta");
		String indirizzo = request.getParameter("indirizzo");
		String provincia = request.getParameter("provincia");

		List<String> errors = new ArrayList<>();

		// errors handling
		if (email == null || email.trim().isEmpty()) {
			errors.add("Il campo email non può essere vuoto!");
		}
		if (password == null || password.trim().isEmpty()) {
			errors.add("Il campo password non può essere vuoto!");
		}
		if (action.equals("registrati")) {
			if (nome == null || nome.trim().isEmpty()) {
				errors.add("Il campo nome non può essere vuoto!");
			}
			if (cognome == null || cognome.trim().isEmpty()) {
				errors.add("Il campo cognome non può essere vuoto!");
			}
		}

		if (!errors.isEmpty()) {
			request.setAttribute("errors", errors);
			if (action.equals("accedi")) {
				request.getRequestDispatcher("/login.jsp").forward(request, response);
			} else {
				request.getRequestDispatcher("/registrati.jsp").forward(request, response);
			}
			return;
		}

		UserDao userDao = new UserDao();

		switch (action) {
		case "accedi": {
			try {
				UserBean ub = userDao.doRetrieveByEmailAndPass(email, password);
				if (ub != null) {
					request.getSession().setAttribute("user", ub);
					
					response.sendRedirect(request.getContextPath() + "/");
				} else {
					errors.add("Credenziali sbagliate!");
					request.setAttribute("errors", errors);
					request.getRequestDispatcher("/login.jsp").forward(request, response);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			break;
		}
		case "registrati": {
			int cap = Integer.parseInt(request.getParameter("cap"));

			try {
				if (userDao.checkUserEmailExistance(email)) {
					errors.add("L'email è già in uso!");
					request.setAttribute("errors", errors);
					request.getRequestDispatcher("/registrati.jsp").forward(request, response);
					return;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			UserBean ub = new UserBean();
			ub.setNome(nome);
			ub.setCognome(cognome);
			ub.setEmail(email);
			ub.setPassword(password);
			ub.setCap(cap);
			ub.setIndirizzo(indirizzo);
			ub.setProvincia(provincia);
			ub.setCitta(citta);

			request.getRequestDispatcher("/login.jsp").forward(request, response);
			try {
				userDao.doSave(ub);

			} catch (SQLException e) {
				e.printStackTrace();
			}
			break;
		}
		}
	}

}
